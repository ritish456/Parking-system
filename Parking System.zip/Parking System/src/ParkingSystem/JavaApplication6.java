/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ParkingSystem;

/**
 *
 * @author DELL
 */
public class JavaApplication6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        new Selector().setVisible(true);
    }
}
